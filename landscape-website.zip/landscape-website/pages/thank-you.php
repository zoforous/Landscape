<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>

<header><h1>Thank You!</h1></header>

<main class="container">
    <p>Your submission has been received. We’ll get back to you soon!</p>
    <a href="../index.php">Return to Home</a>
</main>

</body>
</html>