</main>

<footer class="site-footer">
    <p>&copy; <?= date('Y'); ?> GreenScape Landscaping. All rights reserved.</p>
</footer>
</body>
</html>